//
//  cpptest.h
//  cpptest
//
//  Created by Sensei on 9/16/15.
//  Copyright (c) 2015 Franco "Sensei" Milicchio. All rights reserved.
//

#include <string>

#pragma pack(push, 1)
class stuff
{
public:
    char c;
    int  i;
};
#pragma pack(pop)

extern "C" int doStuff();

extern "C" void usePtr(stuff *p);

extern "C" stuff returnStuff();
