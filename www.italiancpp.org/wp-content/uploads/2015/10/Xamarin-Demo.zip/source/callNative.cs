﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Foundation;
using UIKit;

[assembly: Xamarin.Forms.Dependency (typeof (xamarincpp.iOS.callNative_iOS))]

namespace xamarincpp.iOS
{
	public class callNative_iOS : Icallnative
	{
		public callNative_iOS ()
		{
			// NOP
		}
			
		public int nativeDoStuff()
		{
			return doStuff ();
		}

		public void nativeUsePtr(ref cppclass p)
		{
			usePtr (ref p);
		}

		public cppclass nativeReturnStuff()
		{
			return returnStuff ();
		}

		[DllImport("__Internal")]
		private extern static int doStuff();

		[DllImport("__Internal")]
		private extern static void usePtr(ref cppclass p);

		[DllImport("__Internal")]
		private extern static cppclass returnStuff();

	}
}

