﻿using System;
using Xamarin.Forms;


namespace xamarincpp
{
	public class App : Application
	{
		public App ()
		{
			var native = DependencyService.Get<Icallnative> ();

			cppclass p;
			p.nativec = 0;
			p.nativei = 0;
			native.nativeUsePtr (ref p);

			var r = native.nativeReturnStuff ();

			// The root page of your application
			MainPage = new ContentPage {
				Content = new StackLayout {
					VerticalOptions = LayoutOptions.Center,
					Children = {
						new Label {
							XAlign = TextAlignment.Center,
							Text = "Returned from C++: " + native.nativeDoStuff() + 
								   "\nPointer class: " + p.nativec.ToString() + ", " + p.nativei.ToString() +
								   "\nReturned class: " + r.nativec.ToString() + ", " + r.nativei.ToString()
						}
					}
				}
			};



		}
			
		protected override void OnStart ()
		{
			// Handle when your app starts
		}

		protected override void OnSleep ()
		{
			// Handle when your app sleeps
		}

		protected override void OnResume ()
		{
			// Handle when your app resumes
		}
	}
}

