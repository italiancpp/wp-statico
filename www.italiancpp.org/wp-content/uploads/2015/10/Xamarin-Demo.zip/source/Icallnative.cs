﻿using System;
using System.Linq;
using System.Runtime.InteropServices;

namespace xamarincpp
{
	[StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi, Pack=1)]
	public struct cppclass {
		public byte nativec;
		public int  nativei;
	}

	public interface Icallnative
	{
		int nativeDoStuff();

		void nativeUsePtr(ref cppclass p);

		cppclass nativeReturnStuff();
	}
}

