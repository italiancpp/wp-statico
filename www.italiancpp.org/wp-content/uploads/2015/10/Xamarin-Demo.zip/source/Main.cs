﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Foundation;
using UIKit;

namespace xamarincpp.iOS
{
	public class Application
	{
		// This is the main entry point of the application.
		static void Main (string[] args)
		{

			System.Console.WriteLine (">>>>\n>>>>\n>>>> LIBRARY RESULT: " + doStuff () + "\n>>>>\n>>>>");

			// if you want to use a different Application Delegate class from "AppDelegate"
			// you can specify it here.
			UIApplication.Main (args, null, "AppDelegate");
		}

		[DllImport("__Internal")]
		public extern static int doStuff();
	}


}

[StructLayout(LayoutKind.Explicit)]
public class
{
    [FieldOffset(0)] public byte nativec;
    [FieldOffset(8)] public int  nativei;
}