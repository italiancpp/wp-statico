//
//  cpptest.m
//  cpptest
//
//  Created by Sensei on 9/16/15.
//  Copyright (c) 2015 Franco "Sensei" Milicchio. All rights reserved.
//

#include "cpptest.h"

int doStuff()
{
    std::string s("abcd");
    
    return s.length();
}


void usePtr(stuff *p)
{
    p->c = 'X';
    p->i = 23;
}

stuff returnStuff()
{
    stuff t;
    
    t.c = 'A';
    t.i = 42;
    
    return t;
}
